Thanks for downloading by very badly made tic tac toe game!
Pretty much all you need to do to play the game is to make sure that MessageBoxManager.dll is in the folder and run the game.
Singleplayer pits you against a revolutionary AI which literally just chooses random squares
Multiplayer allows you to play with your friends (if you have any that want to play the game)
To return to the mode select, just close down the game window.
To exit the game, just close the game window and hit "Exit" on the mode select dialog.